https://doi.org/10.5281/zenodo.1215364

In the above Zenodo link, one can find inputs and outputs 
of example 3 (figure 3) of the following paper:

Z. Fan, V. Vierimaa, and Ari Harju, 
GPUQT: An efficient linear-scaling quantum transport code 
fully implemented on graphics processing units, 
Comput. Phys. Commun. 230, 113 (2018). 
https://doi.org/10.1016/j.cpc.2018.04.013

Note that the type of the carbon nanotube (CNT) was
mistakenly written as (7, 7)-CNT in the above paper.
It should be changed to (14, 14)-CNT.
