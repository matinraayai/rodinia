This directory contains examples presented in the paper:

Z. Fan, V. Vierimaa, and Ari Harju, 
GPUQT: An efficient linear-scaling quantum transport code 
fully implemented on graphics processing units, 
Comput. Phys. Commun. 230, 113 (2018). 
https://doi.org/10.1016/j.cpc.2018.04.013

Here, the inputs are in the "lattice" format.
This is more convenient than the "general" format, but is less flexible.
